package Plans;

public interface RecyclerViewInterface {
    void OnItemClick(int position);
}
